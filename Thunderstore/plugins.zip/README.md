# Edge of Night

#### Adds the League of Legends item, Edge of Night, into the game as an uncommon (green) item!

#### Effect: Upon being damaged by an Elite enemy, gain that Elite's power for 3s (+2s per stack). Recharges every 8 seconds.

## Changelog

**0.1.1**

* Add buff/cooldown titles

**0.1.0**

* First release!

## Notes
#### I plan to add sound effects for when Edge of Night gets triggered and when the passive is off cooldown. If you have any other suggestions, please feel free to send me a message on Discord (my username is mangostyles). Thanks for using my mod!

##
The Edge of Night assets are not mine - it is copied directly from the [League of Legends wiki](https://leagueoflegends.fandom.com/wiki/Edge_of_Night).